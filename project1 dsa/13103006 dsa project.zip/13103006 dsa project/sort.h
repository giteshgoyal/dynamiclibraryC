#include <stdio.h> 
int input(int* );
int binarysearch();
void bubblesort();
int insertionsort();
void selectionsort();
void quicksort();
void mode();
int tower();     
