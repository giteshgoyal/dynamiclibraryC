#include<stdio.h> 
void enqueue(int* rear,int max,int* queue); 
void dequeue(int* front,int* rear,int* queue); 
void display1(int front,int rear,int* queue);
