#include<stdio.h>
#include"tree.h"  
#include"stack.h"
#include"sort.h"
#include"linklist.h" 
#include"queue.h"
int tree();
int stack();
void sort();
void linklist();
void queue1();
void miscc();  
